package com.attia12.orderservice.response;

public record OrderLineResponse(
        Integer id,
        double quantity
) {
}
